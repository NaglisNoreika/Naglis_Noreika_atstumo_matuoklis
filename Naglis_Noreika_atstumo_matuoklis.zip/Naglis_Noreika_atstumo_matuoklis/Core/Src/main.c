/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "math.h"
#include "string.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "liquidcrystal_i2c.h"
#include  "stdio.h"
#include "usart.h" 
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
float Matuoja_atstuma(GPIO_TypeDef* trig_port, uint16_t trig_pin,
                      GPIO_TypeDef* echo_port, uint16_t echo_pin,
                      TIM_HandleTypeDef* htim3);
void Send_Data_to_PC(float* mat1, float* mat2, uint8_t sample_no);
void Send_Data_to_LCD(float vidurkis1,float vidurkis2,float skirtumas);
typedef enum {
    UNIT_centimetrai = 0,
    UNIT_metrai  = 1
} MeasurementUnit;
void Load_Unit_From_EEPROM(void);
void Save_Unit_To_EEPROM(void);
MeasurementUnit currentUnit = UNIT_centimetrai;  // Numatyta prad�ioje
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
	HAL_TIM_Base_Start(&htim3);
  /* USER CODE BEGIN 2 */
uint32_t laikas = 0;
HD44780_Init(2);
static uint32_t paskutinis1 = 0;
static float mat1[10] = {0}, mat2[10] = {0};//jutikliu matavimo masyvai
char buffer[32];
uint8_t sample_no = 0;      // matavimo poru skaicius
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

if (HAL_GetTick() - paskutinis1 >= 200 && sample_no < 10) {
    paskutinis1 = HAL_GetTick();
	
	// Atliekami matavimai
    mat1[sample_no] = Matuoja_atstuma(GPIOB, GPIO_PIN_5, GPIOB, GPIO_PIN_4, &htim3);
    mat2[sample_no] = Matuoja_atstuma(GPIOB, GPIO_PIN_0, GPIOA, GPIO_PIN_0, &htim3);
	// Abu jutikliai atliko po viena matavima tai duomenys siunciami i uart
    Send_Data_to_PC(mat1, mat2, sample_no);
    sample_no++;
// tikrinama ar praejo uztektinai laiko ir ar galima siusti duomenis i LCD
        if (sample_no == 10) {
            float suma1 = 0, suma2 = 0;
            for (int i = 0; i < 10; i++) {
                suma1 += mat1[i];
                suma2 += mat2[i];
            }
            float vidurkis1 = suma1 / 10.0f;
            float vidurkis2 = suma2 / 10.0f;
            float skirtumas = fabsf(vidurkis1 - vidurkis2);
						//Duoemys siunciami i LCD atvaizdavimui
            Send_Data_to_LCD(vidurkis1, vidurkis2, skirtumas);
            sample_no = 0; // resetinam cikla
        }
    }
//
static uint8_t last_button_state = 1;
uint8_t button_state = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13); 
if (button_state == 0 && last_button_state == 1) {
    currentUnit = (currentUnit == UNIT_centimetrai) ? UNIT_metrai : UNIT_centimetrai;
    Save_Unit_To_EEPROM();

    char msg[] = "Matavimo vientu pakeitimas\r\n";
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}
last_button_state = button_state;
//
}	
		
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_12;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_USART2
                              |RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

float Matuoja_atstuma(GPIO_TypeDef* trig_port, uint16_t trig_pin,
                      GPIO_TypeDef* echo_port, uint16_t echo_pin,
                       TIM_HandleTypeDef* htim3)
{
	uint32_t laikas;
    HAL_GPIO_WritePin(trig_port, trig_pin, GPIO_PIN_RESET);
		__HAL_TIM_SET_COUNTER(htim3, 0);
    HAL_GPIO_WritePin(trig_port, trig_pin, GPIO_PIN_SET);
    while (__HAL_TIM_GET_COUNTER(htim3) < 10);
    HAL_GPIO_WritePin(trig_port, trig_pin, GPIO_PIN_RESET);

    // naudojama timeout apsauga apsauganti nuo programos pakibimo 
		laikas = HAL_GetTick();
		while (!(HAL_GPIO_ReadPin(echo_port, echo_pin)) && laikas + 25 > HAL_GetTick())
		;
    uint32_t start = __HAL_TIM_GET_COUNTER(htim3);
		
	
		laikas = HAL_GetTick();
		while ((HAL_GPIO_ReadPin(echo_port, echo_pin)) && laikas + 50 > HAL_GetTick());
		uint32_t end = __HAL_TIM_GET_COUNTER(htim3);
	// musu atveju naudojamas 16 bitu laikmatis tai si verte 65536
        uint32_t max = __HAL_TIM_GET_AUTORELOAD(htim3) + 1;
		//jei laikmatis dar nevirsijo savo kamsimalio vertes galetume skaiciuoti laika end-start
		//taciau jei end<start reikia atsizvelgti i perpildyma
    uint32_t trukme = (end >= start) ? (end - start) : (max - start + end);
  // atstumas skaiciuojamas netiesiogiai laikas kuri uztruko signalas pasiekti objekta ir grizti atgal
	// padauginamas is garso greicio ore 0.0343 cm/�s ir padalinamas is 2
    return (trukme * 0.0343f) / 2.0f;
}


void Send_Data_to_PC(float* mat1, float* mat2, uint8_t sample_no) {
    if (sample_no == 0) return;//jei dar niekas neismatuota funkcija nieko nesiuncia
	float tarpine_s1=0,tarpine_s2=0;// laikinosios matavimo verciu sumos
	for(int i=0;i<sample_no;i++){
		tarpine_s1+=mat1[i];
	}
	for(int j=0;j<sample_no;j++){
		tarpine_s2+=mat2[j];
	}
	float einamas_1=tarpine_s1/sample_no;//pirmo jutiklio tarpinis vidurkis
	float einamas_2=tarpine_s2/sample_no;//antro jutiklio tarpinis vidurkis
	float einamas_s=fabsf(einamas_1 - einamas_2);//absoliutine jutikliu vidurkiu skirtumo reiksme
// duomenu siuntimas i uart
	char uartMsg[64];
	if (currentUnit == UNIT_metrai) {
        einamas_1 /= 100.0f;
        einamas_2 /= 100.0f;
        einamas_s /= 100.0f;
        snprintf(uartMsg, sizeof(uartMsg),
                 "Sen1:%.2fm Sen2:%.2fm DIff:%.2fm\r\n",
                 einamas_1, einamas_2, einamas_s);
    } else {
        snprintf(uartMsg, sizeof(uartMsg),
                 "Sen1:%.2fcm Sen2:%.2fcm DIff:%.2fcm\r\n",
                 einamas_1, einamas_2, einamas_s);
    }

    HAL_UART_Transmit(&huart1, (uint8_t*)uartMsg, strlen(uartMsg), HAL_MAX_DELAY);
}
	
void Send_Data_to_LCD(float vidurkis1,float vidurkis2,float skirtumas){
	  // LCD i?vedimas
	char buffer[32];
	//issisaugome originlalias vertes ribu tikrinimui
float v1 = vidurkis1;
    float v2 = vidurkis2;
    float diff = skirtumas;
	
    if (currentUnit == UNIT_metrai) {
        v1 /= 100.0f;
        v2 /= 100.0f;
        diff /= 100.0f;
    }
		//Nustatome ar duomenys matavimo ribose ir kokiais vientais matuojame
    if (vidurkis1 > 30 && vidurkis2 > 30) {
        sprintf(buffer, "1:>30cm  2:>30cm     ");
    } else if (vidurkis1 > 30 && vidurkis2 <= 30) {
        sprintf(buffer, "1:>30cm 2:%.2f%s  ", v2, currentUnit == UNIT_metrai ? "m  " :"cm ");
    } 
		else if (vidurkis1 <= 30 && vidurkis2 > 30) {
        sprintf(buffer, "1:%.2f%s2:>30cm ", v1, currentUnit == UNIT_metrai? "m  " :"cm ");
    } 
		else if (vidurkis1 < 2 && vidurkis2 < 2) {
        sprintf(buffer, "1:<2cm 2:<2cm          ");
    } 
		else if (vidurkis1 >= 2 && vidurkis2 < 2) {
        sprintf(buffer, "1:%.2f%s2:<2cm", v1, currentUnit == UNIT_metrai? "m  " : "cm ");
    } 
		else if (vidurkis1 < 2 && vidurkis2 >= 2) {
        sprintf(buffer, "1:<2cm 2:%.2f%s ", v2, currentUnit == UNIT_metrai ? "m " : "cm ");
    } 
		else {
        sprintf(buffer, "1:%.2f%s2:%.2f%s",
                v1, currentUnit == UNIT_metrai ? "m " : "cm",
                v2, currentUnit == UNIT_metrai ? "m " : "cm ");
    }

    HD44780_SetCursor(0, 0);
    HD44780_PrintStr(buffer);

    // 2 eilute � skirtumas
    if (vidurkis1 > 30 || vidurkis2 > 30 || vidurkis1 < 2 || vidurkis2 < 2) {
        sprintf(buffer, "Skirtumas:Klaida   ");
    } 
		else {
        if (currentUnit == UNIT_metrai)
            sprintf(buffer, "Skirtumas:%.2fm  ", diff);
        else
            sprintf(buffer, "Skirtumas:%.2fcm  ", diff);
    }

    HD44780_SetCursor(0, 1);
    HD44780_PrintStr(buffer);
}

void Save_Unit_To_EEPROM(void) {
    HAL_FLASHEx_DATAEEPROM_Unlock();
    HAL_FLASHEx_DATAEEPROM_Program(TYPEPROGRAMDATA_BYTE, 0x08080000, currentUnit);
    HAL_FLASHEx_DATAEEPROM_Lock();
}
void Load_Unit_From_EEPROM(void) {
    uint8_t value = *(uint8_t*)0x08080000;
    if (value == UNIT_centimetrai || value == UNIT_metrai) {
        currentUnit = (MeasurementUnit)value;
    } else {
        currentUnit = UNIT_centimetrai;
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
